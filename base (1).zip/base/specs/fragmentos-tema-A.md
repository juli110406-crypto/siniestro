# Fragmentos de relevamiento — Andamios y Herramientas del Sur S.R.L. (demo)

Andamios y Herramientas del Sur alquila equipos de obra —andamios,
hormigoneras, amoladoras, generadores— a particulares y a empresas
constructoras. Hoy el alquiler se anota en un remito por duplicado, los
vencimientos se controlan a ojo y todos los meses hay equipos que no
vuelven y discusiones por daños que nadie puede probar. La Gerencia
contrató al equipo para especificar el sistema que va a reemplazar ese
circuito.

| # | Quién lo dijo | Fragmento textual |
|----|---------------|-------------------|
| E1 | Hugo Maidana (Gerente) | «El objetivo es bajar un 30 % los equipos que no vuelven, durante el próximo ejercicio.» |
| E2 | Teresa Godoy (Encargada de mostrador) | «Al alquilar hay que registrar quién se lleva el equipo, cuál es y qué fecha de devolución le corresponde.» |
| E3 | Teresa Godoy | «Si el cliente tiene un equipo vencido sin devolver, no se le alquila nada hasta que lo traiga.» |
| E4 | Hugo Maidana | «Que sea rápido y práctico, así no se hace cola en el mostrador.» |
| E5 | Teresa Godoy | «Al particular le pedimos un depósito de garantía del treinta por ciento del valor del equipo.» |
| E6 | Raúl Cabrera (Jefe de Depósito) | «Es el cincuenta, y a la constructora con cuenta corriente en la práctica no le pedimos nada.» |
| E7 | Raúl Cabrera | «Los equipos con la certificación de seguridad vencida no salen del depósito: van a mantenimiento.» |
| E8 | Hugo Maidana | «Lo hacemos en Access, que es lo que ya está instalado en la máquina del mostrador.» |
| E9 | Raúl Cabrera | «Cuando el cliente reclama que devolvió el equipo sano y nosotros le cobramos un daño, hoy no tenemos cómo probarlo. Habría que poder ver quién lo recibió, cuándo y en qué estado.» |

## Qué se pide

1. `requirements.md`: los requerimientos funcionales y la clasificación
   de los fragmentos que no lo son.
2. `use-cases.md`: el caso de uso **«Registrar el alquiler de un
   equipo»** (fragmentos E2, E3, E5, E6 y E7).
3. `decision-table.md`: la tabla de decisión **«Autorizar el alquiler
   de un equipo»** (fragmentos E3, E5, E6 y E7).
4. Con esas specs, una página web que implemente el caso de uso,
   siguiendo `skill/SKILL.md`.
