# Fragmentos de relevamiento — Envíos del Litoral S.A. (práctica)

Envíos del Litoral recibe y despacha encomiendas en una red de
sucursales. Hoy la encomienda se anota en un talonario, los plazos de
entrega se informan de memoria y todos los meses hay reclamos por
paquetes rotos o demorados que nadie puede reconstruir. La Jefatura
contrató al equipo para especificar el sistema que va a reemplazar ese
circuito.

| # | Quién lo dijo | Fragmento textual |
|----|---------------|-------------------|
| E1 | Delia Iriarte (Jefa de sucursal) | «El objetivo es reducir un 30 % los reclamos por demora, durante el próximo año.» |
| E2 | Marcos Rivero (Empleado de mostrador) | «Al despachar hay que registrar el remitente, el destinatario, el contenido declarado y qué fecha de entrega le corresponde.» |
| E3 | Marcos Rivero | «Si el cliente tiene una encomienda anterior sin abonar, no se le despacha nada hasta que la pague.» |
| E4 | Delia Iriarte | «Que sea ágil y cómodo, así el empleado atiende más rápido.» |
| E5 | Marcos Rivero | «Al interior le damos cinco días hábiles.» |
| E6 | Nora Quiroga (Coordinadora de logística) | «Son siete, y a las localidades de la zona norte en la práctica les prometemos tres.» |
| E7 | Nora Quiroga | «La mercadería peligrosa —inflamables, baterías— no se despacha nunca por vía terrestre común: va por logística especial.» |
| E8 | Delia Iriarte | «Lo armamos en Access, que es lo que ya está instalado en el mostrador.» |
| E9 | Nora Quiroga | «Cuando el cliente reclama que la encomienda llegó rota, hoy no podemos mostrar quién la recibió en mostrador ni en qué estado se declaró. Habría que poder verlo.» |

## Qué se pide

1. `requirements.md`: los requerimientos funcionales y la clasificación
   de los fragmentos que no lo son.
2. `use-cases.md`: el caso de uso **«Registrar el despacho de una
   encomienda»** (fragmentos E2, E3, E5, E6 y E7).
3. `decision-table.md`: la tabla de decisión **«Autorizar el despacho
   de una encomienda»** (fragmentos E3, E5, E6 y E7).
4. Con esas specs, una página web que implemente el caso de uso,
   siguiendo `skill/SKILL.md`.
