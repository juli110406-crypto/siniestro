# Requerimientos — Andamios y Herramientas del Sur (Tema A)

Fuente: `fragmentos-tema-A.md`. Convención: `skill/SKILL.md` (atómico,
verificable, sin tecnología mezclada).

## Requerimientos funcionales

| ID | Requerimiento | Fragmento(s) de origen | Criterio de verificación |
|----|---------------|------------------------|--------------------------|
| RF-01 | El sistema debe registrar, por cada alquiler, el cliente, el equipo y la fecha de devolución. | E2 | Se registra un alquiler y quedan asentados cliente, equipo y fecha de devolución. |
| RF-02 | El sistema debe impedir un nuevo alquiler a un cliente que tenga un equipo vencido sin devolver. | E3 | Un cliente con un equipo vencido no puede llevarse otro. |
| RF-03 | El sistema debe exigir un depósito de garantía calculado sobre el valor del equipo, según el tipo de cliente. [NEEDS CLARIFICATION: E5 dice 30 % para el particular; E6 dice 50 % y que a la constructora con cuenta corriente "en la práctica" no se le pide nada. Ningún fragmento aclara cuál prevalece.] | E5, E6 | Registrado un alquiler, el depósito exigido surge del tipo de cliente y del valor del equipo. |
| RF-04 | El sistema no debe permitir alquilar un equipo cuya certificación de seguridad esté vencida; ese equipo se deriva a mantenimiento. | E7 | Un equipo con certificación vencida no puede registrarse como alquilado. |
| RF-05 | El sistema debe permitir consultar, para cada devolución registrada, quién la recibió, en qué fecha y en qué estado se recibió el equipo. | E9 | Ante un reclamo por daño, se recupera el operador, la fecha y el estado declarado en la recepción. |

> RF-05 es el que casi nadie detecta en el parcial, y es el que resuelve
> el problema real de la empresa: hoy no puede probar los daños.

## Fragmentos que NO son requerimientos funcionales

| Fragmento | Texto | Categoría | Justificación |
|-----------|-------|-----------|----------------|
| E1 | «El objetivo es bajar un 30 % los equipos que no vuelven…» | Objetivo/meta de negocio (KPI) | Es un resultado que busca la organización, no una función del sistema. Sirve para priorizar y trazar. |
| E4 | «Que sea rápido y práctico…» | RNF (no verificable) | "Rápido" y "práctico" no tienen métrica. Hay que convertirlo en un RNF medible, y el número lo define el negocio, no el analista. |
| E8 | «Lo hacemos en Access…» | Restricción técnica / de implementación | Nombra una herramienta y se funda en lo que ya está instalado, no en una necesidad. Sólo sería restricción si la Gerencia la impusiera formalmente. |

## Conflictos u observaciones detectadas

- **Conflicto (RF-03):** depósito de garantía. Teresa Godoy (E5) dice
  30 % del valor del equipo para el particular; Raúl Cabrera (E6) dice
  50 %, y agrega que a la constructora con cuenta corriente, en la
  práctica, no se le pide nada. **No se resuelve acá.** Decide la
  Gerencia.
- **Hueco:** ningún fragmento dice cómo se calcula la fecha de
  devolución (¿la elige el cliente?, ¿hay plazos fijos por equipo?).
