# Casos de uso — Andamios y Herramientas del Sur (Tema A)

## UC-01: Registrar el alquiler de un equipo

**Actor principal:** Encargado de mostrador (un rol, no "Teresa Godoy").

**Actores secundarios:** Cliente (particular o constructora con cuenta
corriente). Sector de Mantenimiento, cuando se deriva un equipo.
La base de datos **no** es un actor: es interna al sistema.

**Precondición:** El cliente está registrado y el equipo existe en el
catálogo del depósito.

**Flujo principal:**
1. El cliente se presenta en el mostrador y solicita un equipo en alquiler.
2. El encargado identifica al cliente y registra el equipo solicitado.
3. El sistema verifica la situación del cliente. «include» Verificar la situación del cliente
4. El sistema informa que el cliente está habilitado.
5. El sistema calcula la fecha de devolución del alquiler. «include» Calcular la fecha de devolución
6. El sistema registra el alquiler, con el depósito de garantía que corresponda, y emite el comprobante.
7. El encargado entrega el equipo y el comprobante al cliente.

**Flujo(s) alternativo(s):**
- **3a.** El cliente tiene un equipo vencido sin devolver: el sistema
  rechaza el alquiler, informa cuál es el equipo adeudado y el caso de
  uso termina sin registrar el alquiler.
- **2a.** El equipo tiene la certificación de seguridad vencida: el
  sistema no permite alquilarlo y lo deriva al sector de Mantenimiento.
  El encargado puede ofrecer otro equipo (vuelve al paso 2) o el caso
  de uso termina.

**Postcondición:** El equipo queda registrado como alquilado, asociado
al cliente, con su fecha de devolución y su depósito de garantía.

**Relaciones con otros casos de uso:**

| Relación | Caso de uso relacionado | Tipo (include/extend) | Justificación |
|----------|--------------------------|------------------------|----------------|
| UC-01 → | Verificar la situación del cliente | include | Se ejecuta siempre: no hay alquiler sin verificar si el cliente está habilitado (E3). |
| UC-01 → | Calcular la fecha de devolución | include | Se ejecuta siempre: todo alquiler tiene fecha de devolución (E2). |
| Registrar el depósito de garantía → UC-01 | Registrar el depósito de garantía | extend | Condicional. Punto de extensión: «el cliente es particular» (paso 6). [NEEDS CLARIFICATION: porcentaje 30 % vs. 50 %, ver RF-03.] |
| Derivar el equipo a recertificación → UC-01 | Derivar el equipo a recertificación | extend | Condicional. Punto de extensión: «la certificación de seguridad está vencida» (paso 2). |

## Fragmentos considerados para este caso de uso

| Fragmento | Qué aporta al caso de uso |
|-----------|------------------------------|
| E2 | Datos a registrar (cliente, equipo, fecha de devolución): pasos 2, 5 y 6, y la postcondición. |
| E3 | Verificación del cliente: paso 3 (include) y flujo alternativo 3a. |
| E5 | Depósito del particular: extend "Registrar el depósito de garantía". |
| E6 | Contradice E5 y excluye a la constructora con cuenta corriente: queda marcado como conflicto, no se resuelve. |
| E7 | Certificación vencida: flujo alternativo 2a y extend "Derivar el equipo a recertificación". |
