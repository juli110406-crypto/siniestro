# Tabla de decisión — Andamios y Herramientas del Sur (Tema A)

## Autorizar el alquiler de un equipo

Fragmentos: E3, E5, E6 y E7.

| Condición / Acción | R1 | R2 | R3 | R4 | R5 (defecto) |
|--------------------|----|----|----|----|--------------|
| C1 · ¿El cliente tiene un equipo vencido sin devolver? | Sí | No | No | No | - |
| C2 · Certificación de seguridad del equipo | - | Vencida | Vigente | Vigente | - |
| C3 · Tipo de cliente | - | - | Particular | Constructora con cuenta corriente | - |
| A1 · Rechazar el alquiler e informar el equipo adeudado | X | | | | |
| A2 · Derivar el equipo al sector de Mantenimiento | | X | | | |
| A3 · Registrar el alquiler | | | X | X | |
| A4 · Exigir depósito de garantía sobre el valor del equipo [NEEDS CLARIFICATION: 30 % (E5) vs. 50 % (E6)] | | | X | | |
| A5 · Exigir el depósito que fije el convenio de cuenta corriente [NEEDS CLARIFICATION: E6 dice que "en la práctica" no se pide nada] | | | | X | |
| A6 · Entregar el comprobante de alquiler | | | X | X | |
| A7 · Derivar a la Gerencia | | | | | X |

**Regla por defecto (R5):** toda situación que estas tres condiciones
no alcanzan a describir (por ejemplo, un tipo de cliente nuevo) se
deriva a la Gerencia, y el alquiler no se registra.

**Cómo se lee esta tabla:** por **primera coincidencia**, de izquierda a
derecha. El guion indica que la condición no importa para esa regla.
Tres condiciones (una binaria y dos de dos valores) dan 8 combinaciones:
R1 cubre 4, R2 cubre 2, y R3 y R4 una cada una. R5 no se dispara con
ninguna combinación de C1 a C3, pero tiene que estar igual.

## Observaciones

- **Conflictos detectados:** depósito de garantía. Teresa Godoy (E5)
  dice 30 % del valor del equipo; Raúl Cabrera (E6) dice 50 %, y que a
  la constructora con cuenta corriente, en la práctica, no se le pide
  nada. Afecta A4 y A5. No se eligió ningún valor.
- **Huecos del material:** no se sabe si "constructora sin cuenta
  corriente" existe como tipo de cliente ni cómo se trataría (hoy cae
  en R5). Tampoco está definido el plazo de devolución.
- **Decisiones de negocio pendientes:** la Gerencia tiene que fijar el
  porcentaje de depósito del particular y confirmar si la constructora
  con cuenta corriente deja o no depósito.
